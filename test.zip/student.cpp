#include "stdafx.h"  
#include "iostream"    
#include <string>
using namespace std;
class Student{
private:
	int No;
	string name;
	string sex;
	int age;
	string birth;
	string nativespace;
	string major;
	string phone;
	string id;
    string qq;
public:
	Student(){};
	Student(int No,string name,string sex,int age,string birth,string nativespace,string major,string phone,string id,string qq){
	this->No = No;
	this->name = name;
	this->sex = sex;
	this->age = age;
	this->birth = birth;
	this->nativespace = nativespace;
	this->major = major;
	this->phone = phone;
	this->id=id;
	this->qq = qq;
	};
	~Student(){};
    int Student::getNo(){
	return this->No;}
	int Student::getAge(){
	return this->age;}
    string Student::getName(){
	return this->name;}
	 string Student::getSex(){
	return this->sex;}
	string Student::getBirth(){
	return this->birth;}
	string Student::getNativespace(){
	return this->nativespace;}
	string Student::getMajor(){
	return this->major;}
	string Student::getPhone(){
	return this->phone;}
    string Student::getQQ(){
	return this->qq;}
	 string Student::getId(){
	return this->id;}
};