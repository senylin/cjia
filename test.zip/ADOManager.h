#if !defined(AFX_ADOCONN_H__56A56674_91DC_43BB_BD09_9A0C8995161E__INCLUDED_)
#define AFX_ADOCONN_H__56A56674_91DC_43BB_BD09_9A0C8995161E__INCLUDED_
#include "manager.cpp"
#include "student.cpp"
#include "stdafx.h"  
#include "iostream"    
#include <list>
#include <string>   
#include <algorithm>
//����1�����Ӷ�ADO��֧��  
#import "C:\Program Files\Common Files\System\ado\msado15.dll" no_namespace rename("EOF","adoEOF")    
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef list<manager> MANAGERLIST;
typedef list<Student> StudentLIST;

class ADOManager{
public:
_ConnectionPtr pConn;
_RecordsetPtr pRec;
_CommandPtr pCmd;
ADOManager(void);
~ADOManager(void);
void OnInitADOConn(void);
void ExitConnect(void);
manager SelectByUser(string user);
MANAGERLIST SelectAll();
bool userExist(string user);
Student SelectStuById(int sno);
StudentLIST SelectStuAll();
bool insertStu(Student s);
bool updateStu(string sql);
// �򿪼�¼��
//_RecordsetPtr& GetRecordSet(_bstr_t bstrSQL);

};
#endif // !defined(AFX_ADOCONN_H__56A56674_91DC_43BB_BD09_9A0C8995161E__INCLUDED_)