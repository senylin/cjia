#include "ADOManager.h"
#include "stdafx.h"  
#include "iostream"    
#include <list>
#include <string>   
#include <algorithm>
#import "C:\Program Files\Common Files\System\ado\msado15.dll" no_namespace rename("EOF","adoEOF")   
using namespace std;  

typedef list<manager> MANAGERLIST;
typedef list<Student> StudentLIST;

ADOManager::ADOManager(void){}
ADOManager::~ADOManager(void){cout<<"clear............"<<endl;}
//�������ݿ�
void ADOManager::OnInitADOConn(void)
{
  CoInitialize(NULL);
  pConn.CreateInstance(__uuidof(Connection));
   pRec.CreateInstance(__uuidof(Recordset));
	 try{
	 pConn->ConnectionString="Provider = SQLOLEDB.1;Persist Security Info = False;User ID=sa;Password=123456789;Initial Catalog =studentManager";
      pConn->Open("","","",adConnectUnspecified);
}
catch (_com_error e)
{
//��ʾ������Ϣ
 cout<<"ad"<<endl;
}
}
//�Ͽ�����
void ADOManager::ExitConnect(void)
{
//�رռ�¼��������
	if(pRec!=NULL){
		pRec.Release();
  	 pRec=NULL;
	}
pConn->Close();
::CoUninitialize();
}
//���û�����ѯ�ʺ�
manager ADOManager::SelectByUser(string user){
	pRec.CreateInstance(__uuidof(Recordset));
	pRec= pConn->Execute("select * from Login",NULL,adCmdText);
	manager m;
	try
	{
	while(!pRec->adoEOF)
	{
		string user1 =(_bstr_t)pRec->GetCollect("users");
		string password = (_bstr_t)pRec->GetCollect("passwords");
		if(user1==user)
		{ manager m2(user1,password);
		 return m2;}
	//	cout<<password<<endl;
		//	cout<<"2"<<endl;
	    pRec->MoveNext();
	}
	return m;
	}catch(_com_error& e)
       {
        cout<<"as"<<endl;
	 }return m;
}
//��ѯ�����ʺ�
MANAGERLIST ADOManager::SelectAll(){
	pRec.CreateInstance(__uuidof(Recordset));
	pRec= pConn->Execute("select * from Login",NULL,adCmdText);
	MANAGERLIST ml ;
	MANAGERLIST::iterator i;
	try
	{
	while(!pRec->adoEOF)
	{
		string user1 =(_bstr_t)pRec->GetCollect("users");
		string password = (_bstr_t)pRec->GetCollect("passwords");
        manager m2(user1,password);
		ml.push_front(m2);
	    pRec->MoveNext();
	}
   /* for(i = ml.begin();i!=ml.end();++i)
	{manager m3 = *i;cout<<m3.getPassword()<<" "; }
	cout<<endl;*/
	return ml;
	}catch(_com_error& e)
       {
        cout<<"as"<<endl;
	 }return ml;
}
//��ѯ�û����Ƿ����
bool ADOManager::userExist(string user){
	pRec.CreateInstance(__uuidof(Recordset));
	pRec= pConn->Execute("select * from Login",NULL,adCmdText);
    bool result = false;
	try
	{
	while(!pRec->adoEOF)
	{
		string user1 =(_bstr_t)pRec->GetCollect("users");
		string password = (_bstr_t)pRec->GetCollect("passwords");
        if(user1==user)result=true;
	    pRec->MoveNext();
	}
	return result;
	}catch(_com_error& e)
       {
        cout<<"as"<<endl;
	 }return result;
}
//��ѯ����ѧ��
StudentLIST ADOManager::SelectStuAll(){
pRec.CreateInstance(__uuidof(Recordset));
	pRec= pConn->Execute("select * from student_base",NULL,adCmdText);
	StudentLIST m2 ;
	StudentLIST::iterator i;
	try
	{
	while(!pRec->adoEOF)
	{
		string no =(_bstr_t)pRec->GetCollect("student_base_num");
		string name = (_bstr_t)pRec->GetCollect("student_base_name");
		string sex = (_bstr_t)pRec->GetCollect("student_base_sex");
		string age = (_bstr_t)pRec->GetCollect("student_base_age");
		string bir = (_bstr_t)pRec->GetCollect("student_base_birthday");
		string native = (_bstr_t)pRec->GetCollect("student_base_native_space");
		string major = (_bstr_t)pRec->GetCollect("student_base_major");
		string phone = (_bstr_t)pRec->GetCollect("student_base_phone_num");
		string id = (_bstr_t)pRec->GetCollect("student_base_IDaddress");
		string qq = (_bstr_t)pRec->GetCollect("student_base_QQ_num");
        Student m(atoi(no.c_str()),name,sex,atoi(age.c_str()),bir,native,major,phone,id,qq);
		m2.push_front(m);
	    pRec->MoveNext();
	}
   /* for(i = ml.begin();i!=ml.end();++i)
	{manager m3 = *i;cout<<m3.getPassword()<<" "; }
	cout<<endl;*/
	return m2;
	}catch(_com_error& e)
       {
        cout<<"as"<<endl;
	 }return m2;
}
//��ѯ����ѧ��
Student ADOManager::SelectStuById(int sno){
pRec.CreateInstance(__uuidof(Recordset));
	pRec= pConn->Execute("select * from student_base",NULL,adCmdText);
	Student s;
	try
	{
	while(!pRec->adoEOF)
	{
		string no =(_bstr_t)pRec->GetCollect("student_base_num");
		if(atoi(no.c_str())==sno){
		string name = (_bstr_t)pRec->GetCollect("student_base_name");
		string sex = (_bstr_t)pRec->GetCollect("student_base_sex");
		string age = (_bstr_t)pRec->GetCollect("student_base_age");
		string bir = (_bstr_t)pRec->GetCollect("student_base_birthday");
		string native = (_bstr_t)pRec->GetCollect("student_base_native_space");
		string major = (_bstr_t)pRec->GetCollect("student_base_major");
		string phone = (_bstr_t)pRec->GetCollect("student_base_phone_num");
		string id = (_bstr_t)pRec->GetCollect("student_base_IDaddress");
		string qq = (_bstr_t)pRec->GetCollect("student_base_QQ_num");
        Student m(atoi(no.c_str()),name,sex,atoi(age.c_str()),bir,native,major,phone,id,qq);
		s=m;	return s;
		}
	    pRec->MoveNext();
	}
	return s;
	}catch(_com_error& e)
       {
        cout<<"as"<<endl;
	 }return s;
}
//����ѧ����Ϣ
bool ADOManager::insertStu(Student s){
		bool result=false;
		char p[32];
		int n = s.getNo();
		itoa(n,p,10);
		string no = p;
	char g[32];
	int a = s.getAge();
		itoa(a,g,10);
		string age = g;
     pRec.CreateInstance(__uuidof(Recordset));
	try
	{ string in = "insert into student_base(student_base_num,student_base_name,student_base_sex,student_base_age,student_base_birthday,student_base_native_space,student_base_major,student_base_phone_num,student_base_IDaddress,student_base_QQ_num)values(";
		string inserts = in+no+",'"+s.getName()+"','"+s.getSex()+"',"+age+",'"+s.getBirth()+"','"+s.getNativespace()+"','"+s.getMajor()+"','"+s.getPhone()+"','"+s.getId()+"','"+s.getQQ()+"')";
		cout<<"0"<<endl;
		 _bstr_t ins = "";
		 cout<<inserts<<endl;
		 ins = inserts.c_str();
	/*pRec= pConn->Execute("insert into student_base(\
	student_base_num,student_base_name,student_base_sex,student_base_age,student_base_birthday,student_base_native_space,\
	student_base_major,student_base_phone_num,student_base_IDaddress,student_base_QQ_num\
		) values(\
	"+s.getNo()+","+s.getName()+","+s.getSex()+","+s.getAge()+","+s.getBirth()+","+s.getNativespace()+","+s.getMajor()+\
	","+s.getPhone()+","+s.getId()+","+s.getQQ()+"\
		)",NULL,adCmdText);*/
		pRec= pConn->Execute(ins,NULL,adCmdText);
		cout<<"1"<<endl;
         return result=true;
	}catch(_com_error& e)
       {
        cout<<"is wrong"<<endl;
	 }
	return result;
}
//�޸�ѧ������
bool ADOManager::updateStu(string sql){
     bool result = false;
	 pRec.CreateInstance(__uuidof(Recordset));
	 cout<<sql<<endl;
	 try
	{
     _bstr_t upd = "";
	 upd = sql.c_str();
	pRec= pConn->Execute(upd,NULL,adCmdText);
	result = true;
	return result;
	}catch(_com_error& e)
       {
        cout<<"�����sql�������"<<endl;
	 }return result;

}
/*
int main(){
  CoInitialize(NULL);
  ADOManager am ;
  am.OnInitADOConn();
  manager x= am.SelectByUser("002");
  cout<<x.getUser()<<endl;
  cout<<x.getPassword()<<endl;
  MANAGERLIST xl = am.SelectAll();
  MANAGERLIST::iterator i;
   for(i = xl.begin();i!=xl.end();++i)
	{manager m3 = *i;cout<<m3.getUser()<<endl;cout<<m3.getPassword()<<endl; }
	cout<<endl;
  StudentLIST sl = am.SelectStuAll();
  StudentLIST::iterator j;
    for(j = sl.begin();j!=sl.end();++j)
	{Student s3 = *j;cout<<s3.getNo()<<endl;}
	cout<<endl;
  am.ExitConnect();
return 0;
}*/
int main(){
	bool managerEnter();
while(true){
	while(true){
cout<<"This is ѧ��ѡ�ι���ϵͳ����������������"<<endl;
cout<<"please input your userid"<<endl;
cout<<"�û�����";
if(managerEnter())break;
}
	
}
return 0;
}

bool managerEnter(){
	void managerMain();
     bool result = false;
    string user;
    cin>>user;
    CoInitialize(NULL);
ADOManager am ;
am.OnInitADOConn();
bool UE = am.userExist(user);
if(UE==false){cout<<"���û��������ڣ�"<<endl;return result;}
cout<<"please input your password"<<endl;
cout<<"����:";
string psw;
cin>>psw;
manager m = am.SelectByUser(user);
if(!(psw ==m.getPassword())){cout<<"�������"<<endl;return result;}

cout<<"��ӭ����ѧ��ѡ��ϵͳ������Ա��"<<endl;
am.ExitConnect();
managerMain();

return result = true;
}
void managerMain()
{
	void selectAllStu();
	void selectStuById();
	void selectStuByMajor();
	void insertStu();
	void updateStu();
	void course();
	void selectCour();
	void updateStuGrade();
	int n = 0;
	while(true){
cout<<"1����ѯ����ѧ����Ϣ"<<endl;
cout<<"2����ѯѧ����Ϣbyѧ��"<<endl;
cout<<"3����ѯѧ����Ϣbyרҵ"<<endl;
cout<<"4������һѧ����Ϣ"<<endl;
cout<<"5���޸�һѧ����Ϣ"<<endl;
cout<<"6���γ̵���ɾ�Ĳ�"<<endl;
cout<<"7��ѡ����Ϣ�Ĳ�ѯ"<<endl;
cout<<"8����ѧ���ɼ��޸�"<<endl;
	cout<<"���������ֲ���ϵͳ��";
	cin>>n;
	switch(n){
	case 1 :selectAllStu();break;
	case 2 :selectStuById();break;
	case 3 :selectStuByMajor();break;
    case 4 :insertStu();break;
	case 5 :updateStu();break;
	case 6 :course();break;
	case 7 :selectCour();break;
	case 8 :updateStuGrade();break;
	default:cout<<"����������������һ��"<<endl;
	}
	}
		cout<<"����Ա�˳�"<<endl;

}
//1
void selectAllStu(){
 CoInitialize(NULL);
  ADOManager am ;
  am.OnInitADOConn();
  StudentLIST sall = am.SelectStuAll();
  StudentLIST::iterator j;
    for(j = sall.begin();j!=sall.end();++j)
	{Student s = *j;cout<<s.getNo()<<endl;}
	cout<<endl;
  am.ExitConnect();
  while(true){
cout<<"continue?y/n"<<endl;
string ans;
cin>>ans;
if(ans=="y")break;}
return;
}
//2
void selectStuById(){
	cout<<"������ѧ��1��";
	int sno ;
	cin>>sno;
 CoInitialize(NULL);
  ADOManager am ;
  am.OnInitADOConn();
  Student s1 = am.SelectStuById(sno);
  //wrong
  if(s1.getName()!=""){
     cout<<"������ѯ��ѧ�Ų�����"<<endl;
	 return;
  }
    cout<<s1.getName()<<endl;
  am.ExitConnect();
  while(true){
cout<<"continue?y/n"<<endl;
string ans;
cin>>ans;
if(ans=="y")break;}
return;
}
//3
void selectStuByMajor(){
	cout<<"�������רҵ��"<<endl;
	string major;
	cin>>major;
CoInitialize(NULL);
  ADOManager am ;
  am.OnInitADOConn();
  StudentLIST sall = am.SelectStuAll();
  StudentLIST::iterator j;
    for(j = sall.begin();j!=sall.end();++j)
	{Student s = *j;
	if(s.getMajor()==major){cout<<s.getName()<<endl;}
	}
	cout<<endl;
  am.ExitConnect();
  while(true){
cout<<"continue?y/n"<<endl;
string ans;
cin>>ans;
if(ans=="y")break;}
return;
}
//4
void insertStu(){
	int No;
	string name;
	string sex;
	int age;
	string birth;
	string nativespace;
	string major;
	string phone;
	string id;
    string qq;
cout<<"������ѧ��������Ϣ��"<<endl;
cout<<"No.:";
cin>>No;
cout<<endl;
cout<<"name:";
cin>>name;
cout<<endl;
cout<<"sex:";
cin>>sex;
cout<<endl;
cout<<"age:";
cin>>age;
cout<<endl;
cout<<"birth:";
cin>>birth;
cout<<endl;
cout<<"nativespace:";
cin>>nativespace;
cout<<endl;
cout<<"major:";
cin>>major;
cout<<endl;
cout<<"phone:";
cin>>phone;
cout<<endl;
cout<<"id:";
cin>>id;
cout<<endl;
cout<<"qq:";
cin>>qq;
cout<<endl;
Student ns(No,name,sex,age,birth,nativespace,major,phone,id,qq);
 ADOManager am ;
  am.OnInitADOConn();
  cout<<"3"<<endl;
  if(am.insertStu(ns))cout<<"success"<<endl;
  else{cout<<"failed"<<endl;}
  am.ExitConnect();
cout<<"end"<<endl;
return;
}
//5
void updateStu(){
cout<<"�������޸����"<<endl;
string sql;
cin>>sql;
 ADOManager am ;
  am.OnInitADOConn();
  if(am.updateStu(sql)){cout<<"�����success"<<endl;}
  else{cout<<"�����failed"<<endl;}
  am.ExitConnect();
  string n;
  cin>>n;

return;
}
void course(){
  while(true){
cout<<"continue?y/n"<<endl;
string ans;
cin>>ans;
if(ans=="y")break;}
return;
}
void selectCour(){
  while(true){
cout<<"continue?y/n"<<endl;
string ans;
cin>>ans;
if(ans=="y")break;}
return;
}
void updateStuGrade(){
  while(true){
cout<<"continue?y/n"<<endl;
string ans;
cin>>ans;
if(ans=="y")break;}
return;
}
